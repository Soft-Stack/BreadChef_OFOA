
## Views
=================

1) Implement Feature:
- when customer click on 'Add To Cart' button, on any item, A bootstrap modal will open
- customer will set quantity and add in add
- then he can click on continue shopping or checkout button
- or he can close that modal with close button

2) Create Item details view:
- when customer click on any item details, it will take to a view where the details of that selected item will be shown
- get the idea from Hardees, https://www.hardees.com/menu/biscuits-and-other-favorites/prime-rib-fried-egg-biscuit

3) Create Cart View:
- check some websites for idea 
- khaadi https://pk.khaadi.com/checkout/cart/
- kfc https://www.kfcpakistan.com/cart
- gourmet https://gourmetfoods.pk/

4) Create Checkout View:
- check some websites for idea (https://pk.khaadi.com/checkout/#shipping)
- here customer fill his order details like name, phone, address,
- And at right side of page, he will see his items and total Bill

 

