

<?php $__env->startSection('pageContent'); ?>

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Items Page</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li>Items Page</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->


    <!-- ======= Whu Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="section-title">
          <h2>Choose your <span>items</span></h2>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="box">
              <span>01</span>
              <h4>Lorem Ipsum</h4>
              <p>Ulamco laboris nisi ut aliquip ex ea commodo consequat. Et consectetur ducimus vero placeat</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <img src="<?php echo e(asset('img/burger.jpg')); ?>" alt="" width="200" class="align-content-center">
              <h4>Triple Decker Club Sandwich</h4>
              <p>Grilled Chicken, Salami egg, cheese, lettuce, tomato onion, spicy garlic sauce & mayonnaise</p>
              <span>Rs.595</span>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <span>03</span>
              <h4> Ad ad velit qui</h4>
              <p>Molestiae officiis omnis illo asperiores. Aut doloribus vitae sunt debitis quo vel nam quis</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Whu Us Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haris/Documents/Projects/BreadChef_OFOA/breadchef_app/resources/views/items.blade.php ENDPATH**/ ?>